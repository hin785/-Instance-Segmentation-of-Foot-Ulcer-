# Instance Segmentation of ulcer > 2025-01-26 1:12am
https://universe.roboflow.com/instance-segmentation-using-yolo-v8-of-foot-ulcer-gyx2l/instance-segmentation-of-ulcer-g8fid

Provided by a Roboflow user
License: CC BY 4.0

